/** Automatically generated file. DO NOT MODIFY */
package com.melashkov.modernartui;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}